/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.ejb.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import za.ac.tut.entities.Expense;

/**
 *
 * @author Mmaga
 */
@Stateless
public class ExpenceFacade extends AbstractFacade<Expense> implements ExpenceFacadeLocal {

    @PersistenceContext(unitName = "ExpenseEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ExpenceFacade() {
        super(Expense.class);
    }

    public double getTotalAmount() {
        Double total = em.createQuery("SELECT SUM(e.amount) FROM Expense e", Double.class)
                .getSingleResult();
        return (total != null) ? total : 0.0;
    }

    public void deleteExpense(int id) {
        Expense e = em.find(Expense.class, id);
        if (e != null) {
            em.remove(e);
        }
    }
    
     public List<Expense> getAllExpenses() {
        return em.createQuery("SELECT e FROM Expense e", Expense.class).getResultList();
    }

}
